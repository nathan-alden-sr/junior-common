﻿using System.Reflection;

[assembly:AssemblyTitle("JuniorCommon.UnitTests")]
