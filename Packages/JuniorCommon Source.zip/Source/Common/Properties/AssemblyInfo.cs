﻿using System.Reflection;

[assembly: AssemblyTitle("JuniorCommon.Common")]
