﻿using System.Reflection;

[assembly:AssemblyTitle("Junior.Common")]